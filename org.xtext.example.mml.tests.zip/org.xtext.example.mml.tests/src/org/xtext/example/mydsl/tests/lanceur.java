package org.xtext.example.mydsl.tests;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import org.eclipse.xtext.testing.InjectWith;
import org.eclipse.xtext.testing.extensions.InjectionExtension;
import org.eclipse.xtext.testing.util.ParseHelper;
import org.junit.jupiter.api.extension.ExtendWith;
import org.xtext.example.mydsl.mml.MMLModel;
import org.xtext.example.mydsl.tests.MmlInjectorProvider;

import com.google.inject.Inject;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtext.testing.InjectWith;
import org.eclipse.xtext.testing.extensions.InjectionExtension;
import org.eclipse.xtext.testing.util.ParseHelper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.xtext.example.mydsl.mml.CSVParsingConfiguration;
import org.xtext.example.mydsl.mml.DataInput;
import org.xtext.example.mydsl.mml.MMLModel;


@ExtendWith(InjectionExtension.class)
@InjectWith(MmlInjectorProvider.class)
public class lanceur 
{
	@Inject
	static ParseHelper<MMLModel> parseHelper;
	
	public static void main(String[] args) throws Exception
	{
		
		
		String str="";
		try 
		{
			str=readTextFile("/home/ensai/textFile");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("file not found");
		}
		finally 
		{
			System.out.println("");
		}
		System.out.println(str);
		System.out.println(parseHelper.parse(str));
		MMLModel result=parseHelper.parse(str);
		System.out.println(result);
	}
	
	
	public static String readTextFile(String path) throws FileNotFoundException
	{
		Scanner in = new Scanner(new FileReader(path));
		StringBuilder sb = new StringBuilder();
		while(in.hasNextLine())
		{
			sb.append(in.nextLine());
			sb.append("\n");
		}
		in.close();
		String outString = sb.toString();
		return outString;
	}
}

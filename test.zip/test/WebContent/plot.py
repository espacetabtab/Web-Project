import plotly as py
import numpy as np
import plotly.graph_objs as go
import csv
import colorlover as cl

#Parameter
path='C:/Users/carol/eclipse-workspace/test/WebContent'
#Credential
py.tools.set_credentials_file(username='nafia', api_key='ukKYstKms9wyqxd50Bk0')

#Data
with open(path+'/metrics.txt','r') as f :
    x = [t for t in csv.reader(f,delimiter="\t")]

with open(path+'/methods.txt','r') as f :
    methods = [t for t in csv.reader(f,delimiter="\t")]
    print(methods)

for i in range(len(methods)):
    with open(path + '/resultats/result'+str(i+1)+".csv", 'r') as f:
        y = [t for t in csv.reader(f, delimiter=";")]
    y = np.array(y)
    y=y.transpose()
    y = [ [ float(mo) for mo in y[t]] for t in range(len(y))]
    y = [np.mean(t) for t in y]
    line = "y"+str(i)+"="+str(y)
    exec(line)

listCol=cl.scales[str(max(len(methods),3))]['qual']['Paired']



data = []
for m in range(len(methods)):
    line = "m"+str(m)+"=go.Bar(x=x,y=y"+str(m)+", name=methods[m][0],"
    line = line + "marker = dict( color = listCol[m] ,"
    line = line + "line=dict(color='rgb(0,0,0)', width=1.5),), opacity=0.6)"
    exec(line)
    line = "data.append(m"+str(m)+")"
    exec(line)

py.plotly.iplot(data, filename='scatter-for-dashboard',auto_open=True)

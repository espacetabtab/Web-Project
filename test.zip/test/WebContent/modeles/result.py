require(dplyr)
require(caret)
require(MLmetrics)
data <-  read.csv("C:/Users/carol/eclipse-workspace/test/WebContent/csv/iris.txt", sep=",")
colX <- which(colnames(data)!=colY)
colY <- c("Sepal.Length")
get_train_test_data <- function(data, train_ratio) {
  file <- data
  file$train <- 0
  file$test <- 0
  training_rows <- sample(1:nrow(file), train_ratio*nrow(file))
  file[training_rows, ]$train <- 1
  if(length(training_rows)<dim(data)[1])
  {
    file[-training_rows, ]$test <- 1
  }
  return(file)
}
d <- get_train_test_data(data, 0.3)
train <- d[which(d$train == 1),]
train <- train[, !(colnames(train) %in% c("train", "test")), drop=FALSE]
Xtrain <- train[colX]
Ytrain <-  as.factor(train[[colY]])

test <- d[which(d$test == 1),]
test <- test[, !(colnames(test) %in% c("train", "test")), drop=FALSE]
Xtest <-  test[colX]
Ytest <-  as.factor(test[[colY]])
f <- function(data, lev = NULL, model = NULL) {

  recall <- Recall(y_pred = data$pred, y_true = data$obs)
precision <- Precision(y_pred = data$pred, y_true = data$obs)
return(c(Recall=recall,precision=precision))
}
TC <- trainControl(method="none",summaryFunction = f)
TG <- expand.grid(C=1)
algo <- "svmLinear"
model <- train(x=Xtrain,y=Ytrain,method=algo,trControl=TC,tuneGrid=TG,type="C-svc")
predictions <- predict(model,Xtest)
  recall <- Recall(y_pred = predictions, y_true = Ytest)
precision <- Precision(y_pred = predictions, y_true = Ytest)
result <- list(Recall=recall,precision=precision)

write.table(x = result, file = "C:/Users/carol/eclipse-workspace/test/WebContent/modeles/result.csv", sep = ";",row.names = FALSE)




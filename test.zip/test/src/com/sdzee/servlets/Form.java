package com.sdzee.servlets;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Form extends HttpServlet {

	 public static final String VUE = "/WEB-INF/form.jsp";
	 public static final String CHAMP_output1 = "output1";
	 public static final String CHAMP_output2 = "output2";
	 public static final String CHAMP_output3 = "output3";
	 public static final String CHAMP_output4 = "output4";
	 public static final String CHAMP_output5 = "output5";

	    
		
	   public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
 
		   
		   request.setAttribute( "ATT_lien", "/bdd" );
					request.setAttribute( "inputpop", "none" );
		 	        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
			    
			   
			   }
				
			   public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
  
  
			         
			        /* R�cup�ration des champs du formulaire. */
				      String output1 = request.getParameter( CHAMP_output1 );
				        String output2 = request.getParameter( CHAMP_output2 );
				        String output3 = request.getParameter( CHAMP_output3 );
				        String output4 = request.getParameter( CHAMP_output4 );
				        String output5 = request.getParameter( CHAMP_output5 );

				        
						request.setAttribute( "CHAMP_output1", output1 );
						request.setAttribute( "CHAMP_output2", output2 );
						request.setAttribute( "CHAMP_output3", output3 );
						request.setAttribute( "CHAMP_output4", output4 );
						request.setAttribute( "CHAMP_output5", output5 );

			        /* Transmission de la paire d'objets request/response � notre JSP */
			        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
			      
			        
			        ArrayList<String> l= new ArrayList<String>();
 			        l.add(output1);
 			        switch(output2) {
 			       case "formlin":
				        l.add("linear");	        	
			        	break;
 			       case "formpol":
				        l.add("polynomial");	        	
			        	break;
 			       case "formrad":
				        l.add("radial");	        	
			        	break;
			        
 			        }
  			        l.add(output3);
 			        l.add(output4);
 			        l.add(output5);
 			        ecriture(l);
			   }
			   

 

			   private void ecriture(ArrayList<String> l) throws IOException {
				   
				   PrintWriter writer = new PrintWriter("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\form.txt", "UTF-8");
				   for(int i=0; i<l.size();i++) {
					   writer.println(l.get(i));
		 		   }
				   writer.close();
				   
				   BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\form.txt"));
				   String line;
				   while ((line = br.readLine()) != null) {
				      System.out.println(line);
				   }
				   br.close();  	
				   
			   }



			}
package com.sdzee.servlets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Bdd extends HttpServlet {
	 public static final String VUE = "/WEB-INF/bdd.jsp";
	 public static final String CHAMP_EMAIL = "Email";
	 public static final String CHAMP_PAYS1 = "pays1";
	 public static final String CHAMP_PAYS2 = "pays2";
	 public static final String CHAMP_PAYS3 = "pays3";

	 
	 public static final ArrayList<String> bases = new ArrayList<String>();

 


		
	   public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
	        /* Affichage de la page d'inscription */
			request.setAttribute( "ATT_lien", "/bdd" );
			request.setAttribute( "inputpop", "none" );
			
			
			ArrayList<String> bases= new ArrayList<String>();
			 BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\csv\\bases.txt"));
			 String line;
			while ((line = br.readLine()) != null) {
			  bases.add(line);
			}
			br.close();  	
			 
			deleteDirectory("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\resultats");
			 
		request.setAttribute( "bases", bases );
			
		
			
			this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	    
	   
	   }
		
	   public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
 	        String lien;
	        String erreurs="Vous n'avez pas s�lectionn� la m�trique";

	        /* R�cup�ration des champs du formulaire. */
	        String email = request.getParameter( CHAMP_EMAIL );
	        String pays1 = request.getParameter( CHAMP_PAYS1 );
	        String pays2 = request.getParameter( CHAMP_PAYS2 );
	        String pays3 = request.getParameter( CHAMP_PAYS3 );

	        request.setAttribute( "CHAMP_EMAIL", email );
			request.setAttribute( "CHAMP_PAYS1", pays1 );
			request.setAttribute( "CHAMP_PAYS2", pays2 );
			request.setAttribute( "CHAMP_PAYS3", pays3 );

	         
	 
	      
	  
	        /* Stockage du r�sultat et des messages d'erreur dans l'objet request */
	        request.setAttribute("ATT_ERREURS", erreurs );
  	        
 	        ArrayList<String> bases= new ArrayList<String>();
		    BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\csv\\bases.txt"));
		    String line;
		    while ((line = br.readLine()) != null) {
		      bases.add(line);
		   }
		   br.close();  	
		request.setAttribute( "bases", bases );
	


	        /* Transmission de la paire d'objets request/response � notre JSP */
	        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	      
 
	        ArrayList<String> l= new ArrayList<String>();
	        l.add(email);
	        if(pays1!=null) {
		        l.add(pays1);	        	
	        }
	        if(pays2!=null) {
		        l.add(pays2);	        	
	        }
	        if(pays3!=null) {
		        l.add(pays3);	        	
	        }
	        ecriture(l);
	   }
	   

	  

	   private void ecriture(ArrayList<String> l) throws IOException {
		   
		   PrintWriter writer = new PrintWriter("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\test2.txt", "UTF-8");
		   for(int i=0; i<l.size();i++) {
			   writer.println(l.get(i));
 		   }
		   writer.close();
		   
		   writer = new PrintWriter("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\metrics.txt", "UTF-8");
		   for(int i=1; i<l.size();i++) {
			   writer.println(l.get(i));
 		   }
		   writer.close();
		   
		   BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\test2.txt"));
		   String line;
		   while ((line = br.readLine()) != null) {
 
		      System.out.println(line);
		   }
		   br.close();  	
		   
	   }

	   static public void deleteDirectory( String emplacement )
	   {
	     File path = new File( emplacement );
	     if( path.exists() )
	     {
	       File[] files = path.listFiles();
	       for( int i = 0 ; i < files.length ; i++ )
	       {
	         if( files[ i ].isDirectory() )
	         {
	           deleteDirectory( path+"\\"+files[ i ] );
	         }
	         files[ i ].delete();
	       }
	     }
	   }

	}
package com.sdzee.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Plot extends HttpServlet {

	 public static final String VUE = "/WEB-INF/plot.jsp";
	 public static final String CHAMP_EMAIL = "Email";

	    public static final String ATT_ERREURS  = "erreurs";
	    public static final String ATT_RESULTAT = "resultat";

		
	   public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
 	      
		   
 	         String[] command2 = { "cmd.exe", "/k", "python C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\plot.py" };
	         Runtime.getRuntime().exec(command2);
	       
		  
           long chrono = 0 ; 

           // Lancement du chrono 
           chrono = java.lang.System.currentTimeMillis() ; 
           long chrono2 = java.lang.System.currentTimeMillis() ; 
           long temps = chrono2 - chrono ; 
           while(temps<10000) {
        	    chrono2 = java.lang.System.currentTimeMillis() ; 
                temps = chrono2 - chrono ; 
               // System.out.println(temps);
       
           }
           // Arret du chrono 
        
          System.out.println("salut");
		   this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	        
	        
	        
	    }
		
	   public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
	                   	      
	        /* Transmission de la paire d'objets request/response � notre JSP */
	        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	    }



	    
	}

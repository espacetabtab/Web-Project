package com.sdzee.servlets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
 

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Fin extends HttpServlet {

	 public static final String VUE = "/WEB-INF/fin.jsp";
	 public static int id = 0;


		
	   public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
	        /* Affichage de la page d'inscription */
			request.setAttribute( "inputpop", "none" );

		   ecriturefichier(id);
		   BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\modeles\\modeles.txt", true)); 
		   writer.write("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\modeles\\language"+id+".txt"+"\r\n");
		   writer.close();
		   BufferedWriter writer3 = new BufferedWriter(new FileWriter("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\methods.txt", true)); 
		   writer3.write("modele "+id+""+"\r\n");
		   writer3.close();

		   id++;
		   this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	    }
		
	   public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
 	        String[] command = { "cmd.exe", "/k", "java -jar C:\\Users\\carol\\Desktop\\lanceur.jar C:/Users/carol/eclipse-workspace/test/WebContent/modeles/modeles.txt C:/Users/carol/eclipse-workspace/test/WebContent/resultats/ C:/Users/carol/eclipse-workspace/test/WebContent/resultats/" };
	        Runtime.getRuntime().exec(command);
	  
	        
	            
	       /* Transmission de la paire d'objets request/response � notre JSP */
       this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	    }
	   
	   
	   
	   public void ecriturefichier(int id) throws IOException{
		   	// R�cup�ration informations premier formulaire
		   String base;
 		   BufferedReader br1 = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\test2.txt"));
			base=br1.readLine();
			base=br1.readLine();
			System.out.println(base);
			String line4;
			String[] metrique= new String[3];
			int i=0;
			while ((line4 = br1.readLine()) != null) {
					
					System.out.println(line4);
					metrique[i]=line4;
					i++;
		  	   }
 			br1.close();
			String lien="C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\csv\\"+base+".txt";
	
		 
			// R�cup�ration informations deuxieme formulaire
			br1 = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\form.txt"));
			String algo1=br1.readLine();
			String algo2=br1.readLine();
			String algo3=br1.readLine();
			String algo4=br1.readLine();
			String algo5=br1.readLine();
			br1.close();
 	
		
			// R�cup�ration informations dernier formulaire
			br1 = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\form2.txt"));
			String algo11=br1.readLine();
			String algo12=br1.readLine();
			String algo13=br1.readLine();
			String algo14=br1.readLine();
			String algo15=br1.readLine();
			br1.close();		   
			
			
			// R�cup�ration de l'information sur le separator
			   br1 = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\csv\\SEPARATOR.txt"));
			   String line;
			   String sep=","; //par d�faut
			   while ((line = br1.readLine()) != null ) {
				   if(line.equals(base)) {
					   sep = br1.readLine();}
				   }
			   
			   br1.close();  
			   
			// R�cup�ration nom variables
				ArrayList<String> v= new ArrayList<String>();
				  br1 = new BufferedReader(new FileReader(lien));
				   String line3;
				   while ((line3 = br1.readLine()) != null) {
				      v.add(line3);
				   }
				   br1.close();  	
 		   
		   
			// Ecriture fichier 
		   PrintWriter writer = new PrintWriter("C:/Users/carol/eclipse-workspace/test/WebContent/modeles/language"+id+".txt", "UTF-8");
		   writer.print("datainput '");
		   String lien2="C:/Users/carol/eclipse-workspace/test/WebContent/csv/"+base+".csv";
		   writer.print(lien2);
		   writer.print("' separator ");
		   writer.println(sep);
		   
		   writer.print("mlframework ");
		   writer.println(algo12);

		   writer.print("algorithm  ");
		   switch(algo1) {
		   case "svm":
			   writer.print("SVM ");
			   writer.print("gamma= ");
			   writer.print(algo5);
 			   writer.print(" C=");
			   writer.print(algo4);
 			   writer.print(" degree= ");
			   writer.print(algo5);
			   writer.print(" kernel= ");
			   writer.print(algo2);
			   writer.print(" classification ");
			   writer.print(algo3);
			   writer.println("-classification");

			   break;
		   case "rf":
 			   writer.print("RF mtry= ");
			   writer.print(algo3);
			   writer.print(" ntrees= ");
			   writer.println(algo4);
			   break;
		   case "lg":
			   
			   writer.println("LogisticRegression");
			   break;
		   case "dt":
 			   writer.print("DT cp= ");
			   writer.println(algo3);
			   writer.print(".");
			   break;
		   }
		   
		   writer.print("formula ");
		   int ind = Integer.parseInt(algo14.substring(5));

		   writer.print(v.get(ind));
		   writer.print(" ~ ");

 		   String[] expl = algo13.split(",");
 		   ind =  Integer.parseInt(expl[0].substring(4));
		   writer.print(v.get(ind));
		   writer.print(" ");
		   if(expl.length>1){
 		   for(int k=1; k<expl.length;k++){
			   writer.print("+ ");
			   ind =  Integer.parseInt(expl[k].substring(4));
			   writer.print(v.get(ind));
 		   }
		   }
		   writer.println("");
		   
		   
	        if(algo11.equals("formcross")) {
 	        	 writer.print("CrossValidation ");	
	        	 writer.print("{");
	        	 writer.print(" numRepetitionCross ");
	        	 writer.print(algo15);	        	
	        	 writer.println(" } ");	        	
	        }
	        else {
	        	 writer.print("TrainingTest ");
	        	 writer.print("{");	        	
	        	 writer.print(" pourcentageTraining ");	
	        	 writer.print(algo15);	        	

	        	 writer.println("} ");	        	
	        }	      
	      for(int k=0; k<metrique.length;k++) {
	    	  		if(metrique[k]!=null) {
	        	 writer.print(metrique[k]);
	        	 writer.print(" ");}
	      }

         writer.close();
		   
	 
       BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\modeles\\language"+id+".txt"));
  	   String line2;
  	   while ((line2 = br.readLine()) != null) {

  	      System.out.println(line2);
  	   }
  	   br.close();  
  	   
	//   PrintWriter writer2 = new PrintWriter("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\modeles\\m.txt", "UTF-8");
	//   writer2.println("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\modeles\\language"+id+".txt"); 
	//   writer2.close();
  	   
	   System.out.println("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\modeles\\language"+id+".txt"+"\n");

	  
	   
	   }
	   
	  

}
 
package com.sdzee.servlets;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Test extends HttpServlet {
 
	 public static final String VUE = "/WEB-INF/test.jsp";
		
	   public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{

		   PrintWriter writer = new PrintWriter("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\modeles\\modeles.txt");
		   writer.close();
		   

		   PrintWriter writer3 = new PrintWriter("C:\\Users\\carol\\eclipse-workspace\\test\\WebContent\\methods.txt");
		   writer3.close();
		   
		   this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	    }
		
	   public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
	        	    }




	}
